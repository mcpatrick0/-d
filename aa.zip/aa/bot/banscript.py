import action as act
import connections as conn
import time
print '1'
db = conn.MySQLConnect()
db.getDBVersion()
print '2'
bot = act.botAction()
print '3'
def updateLocation():
	cmdGetNoLocation = 'SELECT ticketId, ticketIp from t_storage  WHERE ticketLocation IS NULL'
	cmdUpdateLocation = 'UPDATE t_storage SET ticketLocation = %s WHERE ticketId = %s'
	noLocationList = db.getDB(cmdGetNoLocation)
	for item in noLocationList:
		print(item)
		idUpdate = item[0]
		item[1].encode('ascii')
		ipUpdate = item[1]
#		print ipUpdate
		db.postDB(cmdUpdateLocation, (bot.getLocation(ipUpdate), idUpdate))

def doBan():
	cmdGetUnban = 'SELECT ticketIP from t_storage WHERE IpStatus = "Unbanned"'
	unbanDict = db.getDB(cmdGetUnban)
	cmdUpdateStatus = 'UPDATE t_storage SET ticketStatus = %s, IpStatus = %s WHERE ticketIp = %s'
	listA = []
#	print unbanDict
	for item in unbanDict:
		listA.append(str(item[0]))
#	print listA
	bot.resetBlackList()
	bot.updateBlackList(listA)
	d = bot.getBlackList()
#	print "BlackList:",d
	doBanList = bot.IPController_byIPList(d, 'mac')
#	dobanList = bot.Test_byIPList(d, 'no mac')
#	print dobanList
	for item in doBanList:
#		print "IP can ban: ", item
		db.postDB(cmdUpdateStatus, ('Open', 'Banned', item))

def main():
	updateLocation()
	doBan()

if __name__ == '__main__':
	while True:
		main()
		time.sleep(120)
