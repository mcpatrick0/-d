import action as act

bot = act.botAction()

listA = ['10.15.154.62', '10.15.154.44']

bot.resetBlackList()
bot.updateBlackList(listA)
d = bot.getBlackList()

doBanList = bot.IPController_byIPList(d, 'no mac')
print doBanList
