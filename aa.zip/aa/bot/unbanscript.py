#!/usr/bin/python

import sys
import action as act
import connections as conn

idIP = sys.argv[1]
db = conn.MySQLConnection()
bot = act.botAction()

cmdGetIP = 'SELECT ticketIp FROM t_storage WHERE ticketId = %s' % idIP
cmdUpdateStatus = 'UPDATE t_storage SET ticketStatus = %s, IpStatus = %s, ticketCloseTime = CURRENT_TIMESTAMP WHERE ticketId = %s'

unbanIP = db.getDB(cmdGetIP)
listA = []
for item in unbanIP:
	listA.append(str(item[0]))
for ips in listA:
	a = bot.IPController_byIP(ip, 'no mac')
#	a = bot.pingIP('google.com')
	if (a == 0):
		db.postDB(cmdUpdateStatus, ('Closed', 'Released', idIP))
