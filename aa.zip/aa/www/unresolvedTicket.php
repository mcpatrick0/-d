<?php include 'server.php'; ?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>EZMAN - UNRESOLVED TICKETS</title>
        <?php include('style.php'); ?>
    </head>
    <body>
        <div id="wrapper">
            <?php include('nav.php'); ?>
            <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header"><a href="ticketManagement.php">Ticket Management</a> / Unresolved Tickets</h1>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Ticket Management
                            </div>
                            <div class="panel-body">
                                <?php
                                $sql = "SELECT * FROM t_storage WHERE ticketStatus = 'Unresolved' ORDER BY ticketId DESC";
                                include('loadTable.php');
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include('script.php'); ?>

    </body>
</html>
