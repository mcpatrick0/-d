<?php include('server.php'); ?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <title>EZMAN - INDEX</title>
        <?php include('style.php'); ?>
    </head>
    <body>
        <div id="wrapper">
            <?php include('nav.php'); ?>
            <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Dashboard</h1>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-ticket fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">
                                            <?php
                                            $cntTotal = "SELECT COUNT(*) c FROM t_storage";
                                            $rsTotal = $conn->query($cntTotal);
                                            if ($rsTotal->num_rows > 0) {
                                                while ($row = $rsTotal->fetch_assoc()) {
                                                    echo $row['c'];
                                                }
                                            } else {
                                                echo '0';
                                            }
                                            ?>
                                        </div>
                                        <div>Tickets</div>
                                    </div>
                                </div>
                            </div>
                            <a href="#">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-green">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-check-square-o fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">
                                            <?php
                                            $cntReleased = "SELECT COUNT(*) c FROM t_storage WHERE IPstatus='Released'";
                                            $rsReleased = $conn->query($cntReleased);
                                            if ($rsReleased->num_rows > 0) {
                                                while ($row = $rsReleased->fetch_assoc()) {
                                                    echo $row['c'];
                                                }
                                            } else {
                                                echo 0;
                                            }
                                            ?>
                                        </div>
                                        <div>Released IP</div>
                                    </div>
                                </div>
                            </div>
                            <a href="#">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-yellow">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-ban fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">
                                            <?php
                                            $cntBanned = "SELECT COUNT(*) c FROM t_storage WHERE IPstatus='Banned'";
                                            $rsBanned = $conn->query($cntBanned);
                                            if ($rsBanned->num_rows > 0) {
                                                while ($row = $rsBanned->fetch_assoc()) {
                                                    echo $row['c'];
                                                }
                                            } else {
                                                echo '0';
                                            }
                                            ?>
                                        </div>
                                        <div>Banned IP</div>
                                    </div>
                                </div>
                            </div>
                            <a href="#">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-red">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-edit fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">
                                            <?php
                                            $cntUnbanned = "SELECT COUNT(*) c FROM t_storage WHERE IPstatus='Unbanned'";
                                            $rsUnbanned = $conn->query($cntUnbanned);
                                            if ($rsUnbanned->num_rows > 0) {
                                                while ($row = $rsUnbanned->fetch_assoc()) {
                                                    echo $row['c'];
                                                }
                                            } else {
                                                echo '0';
                                            }
                                            ?>
                                        </div>
                                        <div>Unbanned IP</div>
                                    </div>
                                </div>
                            </div>
                            <a href="#">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4>Ticket Status Ratio</h4>
                            </div>
                            <div class="panel-body">
                                <div id="morris-donut-chart">

                                </div>
                                <a class="btn btn-default btn-lg btn-block" href="ticketManagement.php">View All Tickets</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4>Latest Tickets</h4>
                            </div>
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                        <th>ID</th>
                                        <th>IP</th>
                                        <th>Location</th>
                                        <th>Created Time</th>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $sql = "SELECT * FROM t_storage ORDER BY ticketId DESC LIMIT 10";
                                            $result = $conn->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    echo "<tr><td>" . $row['ticketId'] . "</td>";
                                                    echo "<td>" . $row['ticketIp'] . "</td>";
                                                    if ($row['ticketLocation'] == NULL) {
                                                        echo "<td>Data updating...</td>";
                                                    } else {
                                                        echo "<td>" . $row['ticketLocation'] . "</td>";
                                                    }
                                                    echo "<td>" . $row['ticketCreateTime'] . "</td></tr>";
                                                }
                                            } else {
                                                echo "<tr><td colspan='4'>No new records</td></tr>";
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                    <a class="btn btn-default btn-lg btn-block" href="ticketManagement.php">View All Tickets</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        $tOpen = "SELECT COUNT(*) c FROM t_storage WHERE ticketStatus='Open'";
        $rsOpen = $conn->query($tOpen);
        $valueOpen = '0';
        if ($rsOpen->num_rows > 0) {
            while ($row = $rsOpen->fetch_assoc()) {
                $valueOpen = $row['c'];
            }
        }
        $vOpen = json_encode($valueOpen);
        ?>
        <?php
        $tClosed = "SELECT COUNT(*) c FROM t_storage WHERE ticketStatus='Closed'";
        $rsClosed = $conn->query($tClosed);
        $valueClosed = '0';
        if ($rsClosed->num_rows > 0) {
            while ($row = $rsClosed->fetch_assoc()) {
                $valueClosed = $row['c'];
            }
        }
        $vClosed = json_encode($valueClosed);
        ?>
        <?php
        $tUnresolved = "SELECT COUNT(*) c FROM t_storage WHERE ticketStatus='Unresolved'";
        $rsUnresolved = $conn->query($tUnresolved);
        $valueUnresolved = '0';
        if ($rsUnresolved->num_rows > 0) {
            while ($row = $rsUnresolved->fetch_assoc()) {
                $valueUnresolved = $row['c'];
            }
        }
        $vUnresolved = json_encode($valueUnresolved);
        ?>
        <?php include('script.php'); ?>
        <script>
            $(function () {
                var open = <?php echo $vOpen; ?>;
                var closed = <?php echo $vClosed; ?>;
                var unresolved = <?php echo $vUnresolved; ?>;
                Morris.Donut({
                    element: 'morris-donut-chart',
                    data: [{
                            label: "Closed Tickets",
                            value: closed
                        }, {
                            label: "Open Tickets",
                            value: open
                        }, {
                            label: "Unresolved Tickets",
                            value: unresolved
                        }],
                    resize: true
                });
            });
        </script>
    </body>
</html>
