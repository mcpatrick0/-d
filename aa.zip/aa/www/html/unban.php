<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$id = filter_input(INPUT_POST, 'id');
$output = shell_exec('/usr/bin/python /home/max/update8_2018/doan1.0/bot/unbanscript.py 2>&1 '.$id.'');
header("Location: ticketDetail.php?id=$id", true, 301);
echo '<script type="text/javascript">alert("Submitted successfully!")</script>';
exit();
