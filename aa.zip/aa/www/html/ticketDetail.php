<?php include 'server.php'; ?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>EZMAN - DETAIL TICKET NO.
            <?php
            $number = filter_input(INPUT_GET, 'id');
            echo $number;
            ?>
        </title>
        <?php include('style.php'); ?>
    </head>
    <body>
        <div id="wrapper"
        <?php include('nav.php'); ?>
             <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header"><a href="ticketManagement.php">Ticket Management</a> / Ticket no <?php echo $number; ?></h1>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4>Ticket detail</h4>
                            </div>
                            <div class="panel-body">
                                <?php
                                // put your code here
                                $sql = "SELECT * FROM t_storage WHERE ticketId = $number";
                                $detail = $conn->query($sql);
                                if ($detail->num_rows > 0) {
                                    while ($row = $detail->fetch_assoc()) {
                                        echo '<form action="unban.php" method="post">';
                                        echo '<div class="col-lg-6">';
                                        echo '<table class="table table-striped table-bordered table-hover">';
                                        echo '<tr><td class="col-md-2">ID</td><td class="col-md-4"><input type="hidden" name="id" value="' . $row["ticketId"] . '">' . $row["ticketId"] . '</td></tr>';
                                        echo '<tr><td class="col-md-2">IP</td><td class="col-md-4"><input type="hidden" name="ip" value="' . $row["ticketIp"] . '">' . $row["ticketIp"] . '</td></tr>';
                                        echo '<tr><td class="col-md-2">Location</td><td class="col-md-4">' . $row["ticketLocation"] . '</td></tr>';
                                        echo '<tr><td class="col-md-2">Create time</td><td class="col-md-4">' . $row["ticketCreateTime"] . '</td></tr>';
                                        echo '<tr><td class="col-md-2">Closed time</td><td class="col-md-4">' . $row["ticketCloseTime"] . '</td></tr>';
                                        echo '<tr><td class="col-md-2">Ticket detail</td><td class="col-md-4">' . $row["ticketDetail"] . '</td></tr>';
                                        echo '<tr><td class="col-md-2">Ticket Status</td><td class="col-md-4">' . $row["ticketStatus"] . '</td></tr>';
                                        echo '<tr><td class="col-md-2">IP Status</td><td class="col-md-4">' . $row["IPstatus"] . '</td></tr></table>';
                                        echo '</div>';
                                        echo '<div class="col-lg-6">';
                                        if ($row["ticketStatus"] == 'Unresolved') {
                                            echo 'This ticket is unresolved.<br>You can wait for the auto ban system response.<br><br>';
                                        }
                                        if ($row["ticketStatus"] == 'Open') {
                                            echo 'This IP has been banned.<br>You now can go check the device and close the ticket.<br><br>';
                                            echo '<button type="submit" name="unban" value="unban" class="btn btn-primary btn-lg btn-block">Close ticket</button>';
                                        }
                                        if ($row["ticketStatus"] == 'Closed') {
                                            echo 'This ticket is closed<br>You can go check other tickets.';
                                        }
                                        echo '</div></form>';
                                    }
                                } else {
                                    echo "No results found";
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include('script.php'); ?>
        </div>
    </body>
</html>
