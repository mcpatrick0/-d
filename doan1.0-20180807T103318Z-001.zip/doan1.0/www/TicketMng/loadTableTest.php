<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<table width="100%" class="table table-striped table-bordered table-hover" id="myTable">
    <thead>
        <tr>
            <th>ID</th>
            <th>IP</th>
            <th>Location</th>
            <th>Description</th>
            <th>IP Status</th>
            <th>Ticket Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr><td>" . $row['ticketId'] . "</td>";
                echo "<td>" . $row['ticketIp'] . "</td>";
                echo "<td>" . $row['ticketDetail'] . "</td>";
                echo "<td>" . $row['ticketTime'] . "</td>";
                if ($row['IPstatus'] % 2 == 1) {
                    echo "<td>Unbanned</td>";
                } else {
                    echo "<td>Banned</td>";
                }
                if ($row['ticketStatus'] % 2 == 1) {
                    echo "<td>Unresolved</td>";
                } else {
                    echo "<td>Resolved</td>";
                }
                echo "<td><a href='ticketDetail.php'>View Detail</td>";
            }
        }
        ?>
    </tbody>
</table>

