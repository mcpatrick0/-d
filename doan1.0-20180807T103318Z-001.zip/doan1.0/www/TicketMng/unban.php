<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#echo $output;
#echo '<script type="text/javascript">alert("Submitted successfully! '. $output .'")</script>';
$id = filter_input(INPUT_POST, 'id');
$output = shell_exec('/usr/local/bin/python /Users/mac/Desktop/a/unbanscript.py 2>&1 '.$id.'');
header("Location: ticketDetail.php?id=$id", true, 301);
echo '<script type="text/javascript">alert("Submitted successfully! '. $output .'")</script>';
exit();