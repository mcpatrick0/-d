
CREATE DATABASE IF NOT EXISTS doanDB;

USE doanDB; 

CREATE TABLE IF NOT EXISTS t_storage (
ticketId Integer AUTO_INCREMENT PRIMARY KEY,
ticketIp nvarchar(255) NOT NULL,
ticketLocation nvarchar(255),
ticketDetail nvarchar(255),
ticketCreateTime DATETIME DEFAULT CURRENT_TIMESTAMP,
ticketCloseTime DATETIME,
ticketStatus ENUM('Closed', 'Open', 'Unresolved') DEFAULT 'Unresolved',
IPstatus ENUM('Released', 'Banned', 'Unbanned')  DEFAULT 'Unbanned'
);

INSERT INTO t_storage(ticketIp, ticketDetail,ticketStatus,IPstatus)
VALUES 
('10.15.200.17', 'tang 21 Keangnam', 'Closed', 'Released'),
('10.15.128.10', 'shinhan bank Keangnam', 'Closed', 'Released'),
('10.15.160.97', 'doi dien keangnam', 'Open', 'Banned'),
('10.15.225.3', 'Highland keangnam', 'Open', 'Banned'),
('10.15.224.78', 'Gui xe keangnam', 'Unresolved', 'Unbanned'),
('10.15.158.158', 'tang 21 Keangnam', 'Open', 'Banned'),
('10.15.135.1', 'shinhan bank keangnam', 'Closed', 'Released'),
('10.15.165.45', 'Intercontinential keangnam', 'Open', 'Banned'),
('10.15.200.2', 'Parkson', 'Unresolved', 'Unbanned');


CREATE TABLE IF NOT EXISTS table1_test (
ticketId Integer AUTO_INCREMENT PRIMARY KEY,
ticketIp TEXT NOT NULL,
ticketTime DATETIME DEFAULT CURRENT_TIMESTAMP,
ticketStatus bit(1),
ticketDetail TEXT,
IPstatus bit(1)
);

INSERT INTO table1_test(ticketIp, ticketStatus, ticketDetail, IPstatus)
VALUES 
('1.1.1.1', 0, 'tang 21 Keangnam', 0),
('2.2.2.2', 0, 'shinhan bank Keangnam', 1),
('3.3.3.3', 1, 'doi dien keangnam', 0),
('4.4.4.4', 1, 'Highland keangnam', 1),
('5.5.5.5', 0, 'Gui xe keangnam', 0),
('6.6.6.6', 1, 'tang 21 Keangnam', 1),
('7.7.7.7', 0, 'shinhan bank keangnam', 1),
('8.8.8.8', 1, 'Intercontinential keangnam', 1),
('9.9.9.9', 0, 'Parkson', 0);

