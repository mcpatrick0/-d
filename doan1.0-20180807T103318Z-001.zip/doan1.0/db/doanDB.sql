
CREATE DATABASE IF NOT EXISTS doanDB;

USE doanDB; 

CREATE TABLE IF NOT EXISTS t_storage (
ticketId Integer AUTO_INCREMENT PRIMARY KEY,
ticketIp nvarchar(255) NOT NULL,
ticketLocation nvarchar(255),
ticketDetail nvarchar(255),
ticketCreateTime DATETIME DEFAULT CURRENT_TIMESTAMP,
ticketCloseTime DATETIME,
ticketStatus ENUM('Closed', 'Open', 'Unresolved') DEFAULT 'Unresolved',
IPstatus ENUM('Released', 'Banned', 'Unbanned')  DEFAULT 'Unbanned'
);

CREATE TABLE IF NOT EXISTS table1_test (
ticketId Integer AUTO_INCREMENT PRIMARY KEY,
ticketIp TEXT NOT NULL,
ticketTime DATETIME DEFAULT CURRENT_TIMESTAMP,
ticketStatus bit(1),
ticketDetail TEXT,
IPstatus bit(1)
);