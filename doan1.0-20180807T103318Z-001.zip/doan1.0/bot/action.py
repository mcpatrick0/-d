from netmiko import ConnectHandler
import os
import subprocess
import ConfigParser
import sys
#import pexpect
#import getpass

config = ConfigParser.ConfigParser()
config.sections()
#config_path = raw_input("Enter database config path: ")
config.read('/Users/mac/Desktop/a/config.ini')
#config.read('/Users/mac/Desktop/a/config.ini'))
acc = {}
if config.has_section('user'):
	items = config.items('user')
	for item in items:
		acc[item[0]] = item[1]
else:
	raise Exception('{0} not found in the {1} file'.format('user', "config.ini"))

LIST_IP_SWITCH = {'T20T_DS_01': '10.15.200.10', 'T20D_DS_01':'',
				'T21T_DS_01': '10.15.200.70', 'T21D_DS_01':'10.15.200.100',
				'T22T_DS_01' : '10.15.200.130','T22D_DS_01':'10.15.200.160',
				'wifi':[],'CoreSW':'10.15.200.1'}
NAME_BLACK_LIST = {'T20T_DS_01': [], 'T20D_DS_01':[],
				'T21T_DS_01': [], 'T21D_DS_01':[],
				'T22T_DS_01' : [],'T22D_DS_01':[],
				'wifi':[],'CoreSW':[]}

class botAction(object):

#	def init(self):
#		pass

	def __init__(self):
		self.device_type = config.get("user", "device_type")
		self.username = config.get("user", "username")
		self.password = config.get("user", "password")
		self.secret = config.get("user", "secret")

	def printAcc(self):
		print self.device_type
		print " "
		print self.username
		print " "
		print self.password
		print " "
		print self.secret

	def updateTicketStatus():
		pass

	def updateIPStatus():
		pass

	def banIP():
		pass

	def ubbanIP():
		pass

	def checkOK(self):
		print 'Chay duoc roi'

	def getLocation(self, ip_address):
		ip_add = ip_address.strip()
		vlan = int(ip_add.split('.')[2])

		name = ''
		if (vlan) >= 128 and (vlan) <= 135:
			name ='T20D_DS_01'
		elif (vlan == 68) or ((vlan) >= 136 and (vlan) <= 143):
			name = 'T20T_DS_01'
		elif (vlan) >= 144 and (vlan) <= 151:
			name = 'T21D_DS_01'
		elif (vlan) >= 152 and (vlan) <= 159:
			name ='T21T_DS_01'
		elif (vlan) >= 160 and (vlan) <= 167:
			name = 'T22D_DS_01'
		elif (vlan) >= 168 and (vlan) <= 175:
			name = 'T22T_DS_01'
		elif ((vlan) >= 176 and (vlan) <= 191) or (vlan <= 226 and vlan >= 224):
			name = 'CoreSW'
		else:
			name = 'wifi'
		return name

#Function switchIP
#Define the switch IP of an IP
	def switchIP(self, ip_address):
#		ip_address=ip_address.strip()
#		vlan = int(ip_address.split('.')[2])
#		print vlan
#print vlan
		name = self.getLocation(ip_address)
		print name
		NAME_BLACK_LIST[name].append(ip_address)
#		print name
		ip=LIST_IP_SWITCH[name]
		return ip

	def findVlanName(self, ip_address):
	# detail for ticket
		vlan = int(ip_address.split('.')[2])
		return vlan

	def mac_tracker(self, connect, ip):
		output = connect.send_command("show arp | i {0}".format(ip))
		print output.split()[3]
		return output.split()[3]

#Function updateBlackList
#Push detected IP list into NAME_BLACK_LIST
	def updateBlackList(self, IPlist):
		d = NAME_BLACK_LIST
		for item in IPlist:
			self.switchIP(item)
		print d
#		return d


#Function resetBlackList
#Delete IP list in dictionary NAME_BLACK_LIST
	def resetBlackList(self):
#		d = NAME_BLACK_LIST
#		items = d.keys()
		for item in NAME_BLACK_LIST.keys():
			NAME_BLACK_LIST[item] = []
		print NAME_BLACK_LIST

#Funtion getBlackList
#
	def getBlackList(self):
		return NAME_BLACK_LIST

	def pingIP(self, ip_address):
		"""Use the ping utility to attempt to reach the host. We send 5 packets
		('-c 5') and wait 3 milliseconds ('-W 3') for a response. The function
		returns the return code from the ping utility.
		"""
		ret_code = subprocess.call(['ping', '-c', '5', '-W', '3', ip_address], stdout=open(os.devnull, 'w'), stderr=open(os.devnull, 'w'))
		return ret_code

	def testPingIP(self):
		TEST = ['127.0.0.1', 'google.com', 'kenh14.vn', '10.15.200.162']
		IP_STATUS = {}
		for item in TEST:
			IP_STATUS[item] = self.pingIP(item)
		return IP_STATUS

#Funtion 
	def IPController_byIP(self, args, action):
		CONFIG_COMMANDS = []

		ip_of_switch=switchIP(args)
		net_connect = ConnectHandler(device_type = 'cisco_ios',ip=ip_of_switch, username = 'admin.hieutt35',password= 'kxN8f3SpLPujkKo',secret ='cisco')
		net_connect.find_prompt()
		net_connect.enable()
		command = action + " address-table static "+ mac_tracker(net_connect,args) +" vlan " + findVlanName(args) + " drop"
		CONFIG_COMMANDS.append(command)
		net_connect.send_config_set(CONFIG_COMMANDS)
		net_connect.exit_enable_mode()
		net_connect.disconnect()
		return pingIP(args)

	def switch_authenticate(self, switchName, password, passwordSU, r):
		print r.recvuntil('Username: ')
		r.sendline('admin.hieutt35')
		print r.recvuntil('Password: ')
		r.sendline(password)
		print r.recvuntil('>')
		r.sendline('en')
		print r.recvuntil('Password: ')
		r.sendline(passwordSU)
		print r.recvuntil('#')

	def IPController_byIPList(self, dictionary, action):
		CONFIG_COMMANDS = []
		IP_STATUS = []
		for key in dictionary.keys():
			if key == 'CoreSW':
				CONFIG_COMMANDS = []
				r = remote(SWITCH_IP_LIST['CoreSW'], 23)
				self.switch_authenticate('CoreSW', 'kxN8f3SpLPujkKo', 'cisco', r)
				for ip in BLACK_LIST_NAME['CoreSW']:
					try:
						r.sendline('show arp | i {0}'.format(ip))
						mac =  r.recvuntil('#').split()[8]
						CONFIG_COMMANDS.append(mac_dropper(ip,mac))
					except:
						pass
				r.sendline('conf t')
				print r.recvuntil('(config)#')
				for cmd in CONFIG_COMMANDS:
					r.sendline(cmd)
					q.write('{0} {1}\n'.format(datetime.now().strftime('%Y-%m-%d %H:%M:%S'),cmd))
					print r.recvuntil('(config)#')
				r.close()
			else:
				CONFIG_COMMANDS = []
				ip_of_switch = LIST_IP_SWITCH[key]
				net_connect = ConnectHandler(device_type = 'cisco_ios',ip=ip_of_switch, username = 'admin.hieutt35',password= 'kxN8f3SpLPujkKo',secret ='cisco')
				net_connect.find_prompt()
				net_connect.enable()
				for value in dictionary[key]:
					command = action + " address-table static "+ mac_tracker(net_connect,value) +" vlan " + findVlanName(value) + " drop"
					CONFIG_COMMANDS.append(command)
#					net_connect.send_config_set(CONFIG_COMMANDS)
				net_connect.send_config_set(CONFIG_COMMANDS)
				net_connect.exit_enable_mode()
				net_connect.disconnect()
			for ip in dictionary[key]:
				if pingIP(ip) != 0:
					IP_STATUS.append(ip)
		return IP_STATUS

	def Test_byIPList(self, dictionary, action):
		IP_PING = []
		for key in dictionary.keys():
			for ip in dictionary[key]:
				print ip
				IP_PING.append(ip)
		return IP_PING

