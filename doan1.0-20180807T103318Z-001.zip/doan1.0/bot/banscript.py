import action2 as act
import connections as conn

db = conn.MySQLConnection()
bot = act.botAction()

def updateLocation():
	cmdGetNoLocation = 'SELECT ticketId, ticketIp from t_storage  WHERE ticketLocation IS NULL'
	cmdUpdateLocation = 'UPDATE t_storage SET ticketLocation = %s WHERE ticketId = %s'
	noLocationList = db.getDB(cmdGetNoLocation)
	for item in noLocationList:
		print(item)
		idUpdate = item[0]
		item[1].encode('ascii')
		ipUpdate = item[1]
#		print ipUpdate
		db.postDB(cmdUpdateLocation, (bot.getLocation(ipUpdate), idUpdate))

def doBan():
	cmdGetUnban = 'SELECT ticketIP from t_storage WHERE IpStatus = "Unbanned"'
	unbanDict = db.getDB(cmdGetUnban)
	cmdUpdateStatus = 'UPDATE t_storage SET ticketStatus = %s, IpStatus = %s WHERE ticketIp = %s'
	listA = []
#	print unbanDict
	for item in unbanDict:
		listA.append(str(item[0]))
#	print listA
	bot.resetBlackList()
	bot.updateBlackList(listA)
	d = bot.getBlackList()
#	print "BlackList:",d
	doBanList = bot.IPController_byIPList(d, 'no mac')
#	dobanList = bot.Test_byIPList(d, 'no mac')
#	print dobanList
	for item in dobanList:
#		print "IP can ban: ", item
		db.postDB(cmdUpdateStatus, ('Open', 'Banned', item))

def main():
	updateLocation()
	doBan()

if __name__ == '__main__':
	while True:
		main()
		time.sleep(20)