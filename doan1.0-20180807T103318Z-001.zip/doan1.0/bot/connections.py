import mysql.connector
from mysql.connector import MySQLConnection, Error
import ConfigParser
import sys

config = ConfigParser.ConfigParser()
config.sections()
#config_path = raw_input("Enter database config path: ")
#config.read(config_path)
#print(config.read(config_path))
config.read('/Users/mac/Desktop/a/config.ini')
db = {}
if config.has_section('mysql'):
	items = config.items('mysql')
	for item in items:
		db[item[0]] = item[1]
else:
	raise Exception('{0} not found in the {1} file'.format('mysql', "config.ini"))

class MySQLConnection(object):

	def __init__(self):
		self.conn = None
		self.cursor = None

		self.host = config.get("mysql", "host")
		self.user = config.get("mysql", "user")
		self.password = config.get("mysql", "password")
		self.database = config.get("mysql", "database")
		self.conn = mysql.connector.connect(host = self.host, user = self.user, password = self.password, database = self.database)
		self.cursor = self.conn.cursor()

	def __del__(self):
		if self.cursor is not None:
			self.cursor.close()
		if self.conn is not None:
			self.conn.close()

	def getDBVersion(self):
		self.__init__()
		self.cursor.execute("SELECT VERSION()")
		data = self.cursor.fetchone()
		self.__del__()
		print "Database version: %s" % data

	def getDB(self, cmd):
		self.__init__()
		self.cursor.execute(cmd)
		data = self.cursor.fetchall()
		self.__del__()
#		ar = [r[0] for r in data]
#		print ar
#		return ar
#		print array
		return data

	def postDB(self, query, args):
		self.__init__()
		self.cursor.execute(query, args)
		self.conn.commit()
		self.__del__()



